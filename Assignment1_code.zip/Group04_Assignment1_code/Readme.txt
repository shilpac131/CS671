The coding report describes the process and details of a CS671 assignment 1, which includes three code files. One is for classification problem using perceptron with linerly seperable data set(Q.1.1), second is for classification problem using perceptron algorithm for non linearly seperable data set(Q.1.2) and last is for Regression problem using Perceptron algorithm with (Q.2). 
""Warning""
-Change the input data path before running the code as we have provided our own data path.
--For executing classification_linear.py please give the correct data path in lines 21-23.
--For executing classification_non_linear.py please give the correct data path in lines 21.
--For executing regression_linear_and_non_linear.py please give the correct data path in lines 19 and 121.

-After running the code, you have to clsoe the visible plots on screen to view the next plot.    


