The coding report describes the process and details of a CS671 assignment 2, which includes three code files. One is for classification problem using FCNN (Q.1),second is for regression problem using FCNN algorithm for Uni-Variate data set(Q.1.1) and Bi-Variate data set(Q.2.2). 
""Warning""
-Change the input data path before running the code as we have provided our own data path.
-After running the code, you have to close the visible plots on screen to view the next plot.  
