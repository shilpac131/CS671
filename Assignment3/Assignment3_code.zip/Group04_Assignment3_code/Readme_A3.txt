There are 3 compressed zipped folders names: a1v3,a2v3,a3v3 which indicate architecture number and variation number.
architecture 1 has 3 hidden layers, architecture 2 has 4 hidden layers, architecture 3 has 5 hidden layers.
variation number indicated that we experimentally changed the nodes of each layer and now present in the files only those variations which give the best output with rest to the given layer mentioned.

These are the best architectures for the given number of hidden layers.

In each separate zip file contains, .py files which have different optimizer as indicated by their name separated by '_'. For example a1v3_sgd_batch indicated that py file contains sgd and batch optimizer code.