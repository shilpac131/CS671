#!/usr/bin/env python
# coding: utf-8

# In[10]:


import os
import numpy as np
import cv2
from matplotlib import pyplot as plt
from sklearn.metrics import confusion_matrix
from sklearn.metrics import ConfusionMatrixDisplay
import seaborn as sns


# In[11]:


def read_data(path):
    
    train_path = path+"/train"
    test_path = path+"/test"
    validation_path = path+"/val"
    
    tr_data, test_data, val_data = [], [], []
    tr_out, test_out, val_out = [], [], []

    for i in os.listdir(train_path):

        if i != ".DS_Store":
            for j in os.listdir(train_path+"/"+i):
                tr_data.append(cv2.imread(train_path+"/"+i+"/"+j, cv2.IMREAD_GRAYSCALE))
                tr_out.append(i)

            for j in os.listdir(test_path+"/"+i):
                test_data.append(cv2.imread(test_path+"/"+i+"/"+j, cv2.IMREAD_GRAYSCALE))
                test_out.append(i)

            for j in os.listdir(validation_path+"/"+i):
                val_data.append(cv2.imread(validation_path+"/"+i+"/"+j, cv2.IMREAD_GRAYSCALE))
                val_out.append(i)
                
                
    tr_data, test_data, val_data = np.array(tr_data), np.array(test_data), np.array(val_data)
    tr_out, test_out, val_out = np.array(list(map(int, tr_out))), np.array(list(map(int, test_out))), np.array(list(map(int, val_out)))

    return tr_data, test_data, val_data, tr_out, test_out, val_out


# In[12]:


def convert(data):
  out = []
  for i in data:
    if i == 1:
      out.append(0)
    if i == 3:
      out.append(1)
    if i == 6:
      out.append(2)
    if i == 7:
      out.append(3)
    if i == 9:
      out.append(4)

  return np.array(out)


# In[13]:


path = "C:/Users/shilp/OneDrive/Documents/CS671/Group_4/"
tr_data, test_data, val_data, tr_out, test_out, val_out = read_data(path)


# In[14]:


tr_label = convert(tr_out)
val_label = convert(val_out)
test_label = convert(test_out)


# ## **Deep Learning Model**

# In[15]:


import tensorflow as tf
from tensorflow import keras
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input, Dense, Flatten
from tensorflow.keras.optimizers import SGD, Adam
from tensorflow.keras.callbacks import EarlyStopping
from tensorflow.keras import initializers


# In[24]:


initializer = tf.keras.initializers.RandomNormal(mean=0.0, stddev=0.06, seed=42)


# In[25]:


inputs = Input(shape=(28, 28))

x = Flatten(input_shape=(28, 28), name='Input_Layer')(inputs)
x = Dense(256, activation='sigmoid', name='HiddenLayer1', kernel_initializer=initializer)(x)
x = Dense(256, activation='sigmoid', name='HiddenLayer2', kernel_initializer=initializer)(x)
x = Dense(256, activation='sigmoid', name='HiddenLayer3', kernel_initializer=initializer)(x)
outputs = Dense(5, activation='softmax', name='OutputLayer')(x)

model = Model(inputs=inputs, outputs=outputs)


# In[26]:


# model.summary()


# #SGD

# In[27]:


optimizer = SGD(learning_rate=0.001,name='SGD') #Normal Gradient Descent


# In[28]:


model.compile(optimizer=optimizer,
             loss='sparse_categorical_crossentropy',
             metrics=['accuracy'])


# In[29]:


callback = EarlyStopping(monitor="loss",min_delta=0.0001, verbose = 0, restore_best_weights=True, patience = 1)


# In[30]:


model_fit = model.fit(tr_data, tr_label,shuffle=True,epochs=100000000, batch_size=1, callbacks=callback)


# In[31]:


plt.plot(model_fit.history['loss'])
plt.title("Average Training Error Vs Epoch")
plt.xlabel("epochs")
plt.ylabel("Average error")
plt.show()
#256,256,256 batch 0.8


# In[34]:


loss, accuracy = model.evaluate(tr_data, tr_label)


# In[36]:


loss, accuracy = model.evaluate(val_data, val_label)


# batch

# In[51]:


initializer = tf.keras.initializers.RandomNormal(mean=0.0, stddev=0.06, seed=42)
inputs = Input(shape=(28, 28))

x = Flatten(input_shape=(28, 28), name='Input_Layer')(inputs)
x = Dense(256, activation='sigmoid', name='HiddenLayer1', kernel_initializer=initializer)(x)
x = Dense(256, activation='sigmoid', name='HiddenLayer2', kernel_initializer=initializer)(x)
x = Dense(256, activation='sigmoid', name='HiddenLayer3', kernel_initializer=initializer)(x)

outputs = Dense(5, activation='softmax', name='OutputLayer')(x)

model = Model(inputs=inputs, outputs=outputs)


# In[52]:


optimizer = SGD(learning_rate=0.001,name='SGD') #Normal Gradient Descent


# In[53]:


model.compile(optimizer=optimizer,
             loss='sparse_categorical_crossentropy',
             metrics=['accuracy'])


# In[54]:


callback = EarlyStopping(monitor="loss",min_delta=0.0001, verbose = 0, restore_best_weights=True, patience = 15)


# In[ ]:


model_fit = model.fit(tr_data, tr_label,shuffle=True,epochs=100000000, batch_size=11385, callbacks=callback)


# In[ ]:


print(model_fit.history)


# In[ ]:




