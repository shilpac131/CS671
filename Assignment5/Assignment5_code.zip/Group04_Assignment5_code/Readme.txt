The following folder contains 2 folders such as:

For Question1(First folder) :

Primarily three architectures are done with and without transfer learning(as mentioned in the question):
'Q1a_b_c_wo_transfer.py' contains question 1 a,b,c without transfer learning
'Q1a_b_c_transfer.py' contains question 1 a,b,c with transfer learning
'Q1d.py' contains question 1 d, done on the best architecture which in our case is Architecture 2 with transfer learning.

------------------------------------------------------------------------------------------------------------------------------------

For Question2(Second Folder) :
We have modified the classification layer of VGG19 to 5 output nodes. 
'Q2a_d.py' contains question 2 a and d, as it is was done together
'Q2b.py' contains question 2 b, only.
'Q2c.py' contains question 2 c, only.
