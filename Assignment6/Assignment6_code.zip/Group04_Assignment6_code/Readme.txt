The following folder contains 2 sub-folders such as:

Question_1(First sub-folder) :

Contains 2 file such as 'RNN.py' and 'LSTM.py' for RNN and LSTM for Handwritten character dataset. The data has been padded with value 2 in question 1 and normalized in range (0,1). 
We have experimented with the hyperparamters and included 5 such architectures in the code as well as report. 


------------------------------------------------------------------------------------------------------------------------------------


Question_2(Second sub-folder) :

Contains 2 file such as 'RNN.py' and 'LSTM.py' for RNN and LSTM for Consonant Vowel (CV) segment dataset. The data has been padded with value -1 in question 2. 
We have experimented with the hyperparamters and included 5 such architectures in the code as well as report. 